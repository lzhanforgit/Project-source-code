import { OrderbyTimePipePipe } from './orderby-time-pipe.pipe';

describe('OrderbyTimePipePipe', () => {
  it('create an instance', () => {
    const pipe = new OrderbyTimePipePipe();
    expect(pipe).toBeTruthy();
  });
});
