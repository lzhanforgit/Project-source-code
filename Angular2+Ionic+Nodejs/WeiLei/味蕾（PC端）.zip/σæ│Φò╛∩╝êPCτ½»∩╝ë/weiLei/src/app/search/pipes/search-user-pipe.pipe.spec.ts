import { SearchUserPipePipe } from './search-user-pipe.pipe';

describe('SearchUserPipePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchUserPipePipe();
    expect(pipe).toBeTruthy();
  });
});
