import { SearchRecipePipe } from './search-recipe.pipe';

describe('SearchRecipePipe', () => {
  it('create an instance', () => {
    const pipe = new SearchRecipePipe();
    expect(pipe).toBeTruthy();
  });
});
