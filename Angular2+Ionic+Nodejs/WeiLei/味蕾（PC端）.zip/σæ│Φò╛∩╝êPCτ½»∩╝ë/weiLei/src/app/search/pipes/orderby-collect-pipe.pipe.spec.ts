import { OrderbyCollectPipePipe } from './orderby-collect-pipe.pipe';

describe('OrderbyCollectPipePipe', () => {
  it('create an instance', () => {
    const pipe = new OrderbyCollectPipePipe();
    expect(pipe).toBeTruthy();
  });
});
