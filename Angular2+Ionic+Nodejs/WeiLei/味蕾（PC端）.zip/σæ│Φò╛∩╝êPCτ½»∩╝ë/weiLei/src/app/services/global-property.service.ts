import { Injectable } from '@angular/core';

@Injectable()
export class GlobalPropertyService {
  _val:any;
  _searchText:string;//搜索
  hiddenNavs = false;
  _recipeName:any="wda";
  user_icon = 'http://owigmgx25.bkt.clouddn.com/head_pic02.jpg' ;
  constructor() {}

}
