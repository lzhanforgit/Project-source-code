import { OrderbytimePipe } from './orderbytime.pipe';

describe('OrderbytimePipe', () => {
  it('create an instance', () => {
    const pipe = new OrderbytimePipe();
    expect(pipe).toBeTruthy();
  });
});
