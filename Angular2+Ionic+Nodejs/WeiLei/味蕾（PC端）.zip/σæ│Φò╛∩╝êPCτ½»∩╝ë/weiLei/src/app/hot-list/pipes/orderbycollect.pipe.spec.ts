import { OrderbycollectPipe } from './orderbycollect.pipe';

describe('OrderbycollectPipe', () => {
  it('create an instance', () => {
    const pipe = new OrderbycollectPipe();
    expect(pipe).toBeTruthy();
  });
});
