import {Component, OnInit} from '@angular/core';
import {MenuServiceService} from './../../services/menu-service.service';
import {ActivatedRoute, ParamMap} from '@angular/router';
import {Router} from '@angular/router';

@Component({
  selector: 'app-referto-do',
  templateUrl: './referto-do.component.html',
  styleUrls: ['./referto-do.component.css'],
  providers: [MenuServiceService]
})
export class RefertoDoComponent implements OnInit {
  MenuWorks: any;
  length: any;
  _val: any;

  constructor(private route: ActivatedRoute,
              private MenuD: MenuServiceService,
              private router: Router,) {
  }

  ngOnInit() {
    const that = this;
    that._val = that.route.snapshot.paramMap.get('val');
    that.MenuD.getMenuWorks(that._val, function (result) {
      /*console.log('1111');*/
      /*console.log(result);*/
      if (result.length) {
        that.MenuWorks = result;
      }
      that.length = result.length;
      // console.log(that.MenuWorks);
    });
  }

  check() {
    const val = this.route.snapshot.paramMap.get('val');
    this._val = val;
    if (!sessionStorage.getItem('ID')) {
      if (confirm("你还没有登录，是否去登录？")) {
        this.router.navigate(['/login']);
      }
    }
    else {
      this.router.navigate(['/uploading', this._val]);
    }
  }

}
