import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-carouse',
  templateUrl: './carouse.component.html',
  styleUrls: ['./carouse.component.css']
})
export class CarouseComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
