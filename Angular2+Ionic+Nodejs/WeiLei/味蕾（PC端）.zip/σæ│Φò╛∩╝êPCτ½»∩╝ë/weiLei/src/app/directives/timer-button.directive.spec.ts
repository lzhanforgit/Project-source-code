import { TimerButtonDirective } from './timer-button.directive';

describe('TimerButtonDirective', () => {
  it('should create an instance', () => {
    const directive = new TimerButtonDirective();
    expect(directive).toBeTruthy();
  });
});
