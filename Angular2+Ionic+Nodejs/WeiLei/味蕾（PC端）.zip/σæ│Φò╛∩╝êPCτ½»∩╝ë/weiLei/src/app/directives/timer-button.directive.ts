import { Directive } from '@angular/core';

@Directive({
  selector: '[appTimerButton]'
})
export class TimerButtonDirective {

  constructor() { }

}
