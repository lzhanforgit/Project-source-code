import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { PaysuccessPage } from './paysuccess';

@NgModule({
  declarations: [
    PaysuccessPage,
  ],
  imports: [
    IonicPageModule.forChild(PaysuccessPage),
  ],
})
export class PaysuccessPageModule {}
