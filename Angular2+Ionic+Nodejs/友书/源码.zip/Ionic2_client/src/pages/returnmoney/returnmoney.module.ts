import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { ReturnmoneyPage } from './returnmoney';

@NgModule({
  declarations: [
    ReturnmoneyPage,
  ],
  imports: [
    IonicPageModule.forChild(ReturnmoneyPage),
  ],
})
export class ReturnmoneyPageModule {}
