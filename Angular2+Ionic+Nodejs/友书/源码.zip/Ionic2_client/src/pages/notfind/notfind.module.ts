import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { NotfindPage } from './notfind';

@NgModule({
  declarations: [
    NotfindPage,
  ],
  imports: [
    IonicPageModule.forChild(NotfindPage),
  ],
})
export class NotfindPageModule {}
