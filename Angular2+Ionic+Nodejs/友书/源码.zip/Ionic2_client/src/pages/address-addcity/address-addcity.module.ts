import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { AddressAddcityPage } from './address-addcity';

@NgModule({
  declarations: [
    AddressAddcityPage,
  ],
  imports: [
    IonicPageModule.forChild(AddressAddcityPage),
  ],
})
export class AddressAddcityPageModule {}
