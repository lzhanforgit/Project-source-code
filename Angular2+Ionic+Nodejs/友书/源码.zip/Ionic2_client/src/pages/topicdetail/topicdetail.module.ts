import { NgModule } from '@angular/core';
import { IonicPageModule } from 'ionic-angular';
import { TopicdetailPage } from './topicdetail';

@NgModule({
  declarations: [
    TopicdetailPage,
  ],
  imports: [
    IonicPageModule.forChild(TopicdetailPage),
  ],
})
export class TopicdetailPageModule {}
