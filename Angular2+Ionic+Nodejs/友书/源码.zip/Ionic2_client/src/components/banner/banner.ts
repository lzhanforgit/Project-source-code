import {Component, ViewChild, WrappedValue} from '@angular/core';
import {Slides} from "ionic-angular";
import {NgFor, NgForOf} from "@angular/common";

@Component({
  selector: 'banner',
  templateUrl: 'banner.html',
})
export class BannerComponent {
  // @ViewChild(Slides) mySlides: Slides;
  // imgs = ['banner1.jpg','banner2.jpg','banner3.jpg'];

  constructor() {
  }


}
