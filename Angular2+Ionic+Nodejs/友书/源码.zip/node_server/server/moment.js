var moment=require("moment");

console.log(moment().add(7,'hour'));