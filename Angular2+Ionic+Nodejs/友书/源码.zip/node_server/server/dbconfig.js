
var options={
    host:"rm-uf6uhx76ggo98k50wo.mysql.rds.aliyuncs.com",
    port:"3306",
    //数据库
    database:"friendbook",
    user:"root",
    password:'clhs@123456'
};
exports.options=options;