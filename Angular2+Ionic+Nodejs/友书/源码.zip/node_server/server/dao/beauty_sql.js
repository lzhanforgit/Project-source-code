exports.sql={
    //根据book_id获取美言佳句
    getBeauty:"call getBeauty(?,@result)",
};

