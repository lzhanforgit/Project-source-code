import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payovertime',
  templateUrl: './payovertime.component.html',
  styleUrls: ['./payovertime.component.css']
})
export class PayovertimeComponent implements OnInit {

  constructor() { }

  ngOnInit() {

  }

}
