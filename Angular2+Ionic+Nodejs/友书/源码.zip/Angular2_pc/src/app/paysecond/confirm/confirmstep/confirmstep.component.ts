import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-confirmstep',
  templateUrl: './confirmstep.component.html',
  styleUrls: ['./confirmstep.component.css']
})
export class ConfirmstepComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
