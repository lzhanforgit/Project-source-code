import { FindbookPipe } from './findbook.pipe';

describe('FindbookPipe', () => {
  it('create an instance', () => {
    const pipe = new FindbookPipe();
    expect(pipe).toBeTruthy();
  });
});
