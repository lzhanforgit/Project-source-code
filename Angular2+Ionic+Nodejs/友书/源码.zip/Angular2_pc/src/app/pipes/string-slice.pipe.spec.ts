import { StringSlicePipe } from './string-slice.pipe';

describe('StringSlicePipe', () => {
  it('create an instance', () => {
    const pipe = new StringSlicePipe();
    expect(pipe).toBeTruthy();
  });
});
