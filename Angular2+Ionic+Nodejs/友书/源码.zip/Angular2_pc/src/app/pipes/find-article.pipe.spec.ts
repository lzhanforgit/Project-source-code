import { FindArticlePipe } from './find-article.pipe';

describe('FindArticlePipe', () => {
  it('create an instance', () => {
    const pipe = new FindArticlePipe();
    expect(pipe).toBeTruthy();
  });
});
