import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bootom',
  templateUrl: './bootom.component.html',
  styleUrls: ['./bootom.component.css']
})
export class BootomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
