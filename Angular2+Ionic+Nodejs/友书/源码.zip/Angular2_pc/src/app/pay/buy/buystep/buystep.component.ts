import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-buystep',
  templateUrl: './buystep.component.html',
  styleUrls: ['./buystep.component.css']
})
export class BuystepComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
